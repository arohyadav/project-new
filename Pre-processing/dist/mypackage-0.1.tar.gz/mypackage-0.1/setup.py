from setuptools import setup, find_packages

# Read the package requirements from requirements.txt
with open('requirements.txt') as f:
    requirements = f.read().splitlines()

setup(
    name='mypackage',  # Replace with your package name
    version='0.1',
    packages=find_packages(include=['data_processing.*']),
    install_requires=requirements,  # List of package dependencies from requirements.txt
    entry_points={
        'console_scripts': [
            'mydataprocessing = main:main',  # Replace 'main' with the name of your main script
        ],
    },
)
